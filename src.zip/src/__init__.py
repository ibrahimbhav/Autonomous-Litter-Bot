from . import brains, camera, distance_sensor, motor, params, vehicle

import RPi.GPIO
RPi.GPIO.setmode(RPi.GPIO.BCM)
