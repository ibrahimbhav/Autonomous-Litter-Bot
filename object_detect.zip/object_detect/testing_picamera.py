# Step 1: Import necessary modules
from picamera2 import Picamera2, Preview
import time

# Step 3: Create a Picamera2 object
picam2 = Picamera2()

# Step 4: Create camera configuration for still images
camera_config = picam2.create_still_configuration(main={"size": (1920, 1080)}, lores={"size": (640, 480)}, display="lores")

# Step 5: Load the configuration
picam2.configure(camera_config)

# Step 6: Start the preview window and camera
picam2.start_previ
ew(Preview.QTGL)
picam2.start()

# Step 7: Pause for 2 seconds
time.sleep(2)

# Step 8: Capture an image and save it as test.jpg
picam2.capture_file("test.jpg")

# End of code
